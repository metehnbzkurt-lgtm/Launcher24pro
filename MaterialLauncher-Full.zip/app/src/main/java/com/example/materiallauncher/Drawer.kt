package com.example.materiallauncher

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings as SettingsIcon
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

typealias AuthRequester = (() -> Unit) -> Unit

private data class GroupRequest(val app: LaunchApp?)

private fun firstLetter(label: String): String =
    label.trim().take(1).uppercase(Locale("tr", "TR")).ifEmpty { "#" }

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AppDrawer(
    initialQuery: String,
    focusSearch: Boolean,
    onClose: () -> Unit,
    onLaunch: (String) -> Unit,
    onAddHome: (String) -> Unit,
    onSettings: () -> Unit,
    onShortcut: (String, String) -> Unit,
    onAppInfo: (String) -> Unit,
    onUninstall: (String) -> Unit,
    requestAuth: AuthRequester
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf(initialQuery) }
    var tab by remember { mutableIntStateOf(0) }
    var showHidden by remember { mutableStateOf(false) }
    var menuApp by remember { mutableStateOf<LaunchApp?>(null) }
    var groupPick by remember { mutableStateOf<LaunchApp?>(null) }
    var newGroup by remember { mutableStateOf<GroupRequest?>(null) }
    val gridState = rememberLazyGridState()
    val focus = remember { FocusRequester() }

    BackHandler { onClose() }

    val searchPos = Settings.str("drawerSearch", "Alt")
    val freqOn = Settings.bool("frequentApps", true)
    val fast = Settings.bool("fastScroll", true)
    val hideOn = Settings.bool("hideApps", true)
    val cols = Settings.grid("drawerGrid", "5×5").first

    LaunchedEffect(focusSearch) {
        if (focusSearch && searchPos != "Hiçbiri") {
            delay(250)
            try { focus.requestFocus() } catch (e: Exception) { }
        }
    }

    val groups = UserData.groups
    val groupNames = groups.keys.toList()
    val firstGroupTab = if (freqOn) 2 else 1
    val tabLabels = buildList {
        add("Tümü")
        if (freqOn) add("Sık kullanılan")
        addAll(groupNames)
    }
    val sel = tab.coerceIn(0, tabLabels.size - 1)
    val groupName: String? = if (sel >= firstGroupTab) groupNames.getOrNull(sel - firstGroupTab) else null

    val base: List<LaunchApp> = when {
        sel == 0 -> AppRepo.apps
        freqOn && sel == 1 -> UserData.frequent().mapNotNull { AppRepo.index[it] }
        else -> (groupName?.let { groups[it] } ?: emptyList()).mapNotNull { AppRepo.index[it] }
    }
    val q = query.trim()
    val list = base.filter {
        (showHidden || it.packageName !in UserData.hidden) &&
            (q.isEmpty() || it.label.contains(q, ignoreCase = true))
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background.copy(alpha = 0.97f)) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars).imePadding()) {
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Uygulamalar", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
                if (hideOn) {
                    IconButton(onClick = {
                        if (showHidden) showHidden = false else requestAuth { showHidden = true }
                    }) {
                        Icon(if (showHidden) Icons.Default.Visibility else Icons.Default.VisibilityOff, "Gizli uygulamalar")
                    }
                }
                IconButton(onClick = onSettings) { Icon(Icons.Default.SettingsIcon, "Ayarlar") }
            }

            if (searchPos == "Üst") {
                DrawerSearch(query, { query = it }, focus,
                    onEnter = { if (list.size == 1) onLaunch(list[0].packageName) },
                    onShortcut = { id -> onShortcut(id, query) })
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                ScrollableTabRow(
                    selectedTabIndex = sel,
                    edgePadding = 8.dp,
                    modifier = Modifier.weight(1f),
                    containerColor = Color.Transparent,
                    divider = {}
                ) {
                    tabLabels.forEachIndexed { i, label ->
                        Tab(selected = i == sel, onClick = { tab = i }, text = { Text(label, maxLines = 1) })
                    }
                }
                IconButton(onClick = { newGroup = GroupRequest(null) }) { Icon(Icons.Default.Add, "Grup ekle") }
            }

            if (groupName != null) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Grup: $groupName", Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
                    TextButton(onClick = { UserData.deleteGroup(groupName); tab = 0 }) { Text("Grubu sil") }
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (list.isEmpty()) {
                    Text(
                        if (AppRepo.loaded) "Uygulama bulunamadı" else "Yükleniyor…",
                        Modifier.align(Alignment.Center),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(cols),
                    state = gridState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 8.dp, end = if (fast) 28.dp else 8.dp, top = 8.dp, bottom = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(list, key = { it.packageName }) { app ->
                        DrawerTile(
                            app = app,
                            dim = app.packageName in UserData.hidden,
                            locked = app.packageName in UserData.locked,
                            onClick = { onLaunch(app.packageName) },
                            onLong = { menuApp = app }
                        )
                    }
                }
                if (fast && sel == 0 && q.isEmpty() && list.size > 20) {
                    val letters = list.map { firstLetter(it.label) }.distinct()
                    Column(
                        Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(24.dp)
                            .pointerInput(list) {
                                detectTapGestures { pos ->
                                    val i = (pos.y / size.height * letters.size).toInt().coerceIn(0, letters.size - 1)
                                    val idx = list.indexOfFirst { firstLetter(it.label) == letters[i] }
                                    if (idx >= 0) scope.launch { gridState.scrollToItem(idx) }
                                }
                            }
                            .pointerInput(list) {
                                detectVerticalDragGestures { change, _ ->
                                    val i = (change.position.y / size.height * letters.size).toInt().coerceIn(0, letters.size - 1)
                                    val idx = list.indexOfFirst { firstLetter(it.label) == letters[i] }
                                    if (idx >= 0) scope.launch { gridState.scrollToItem(idx) }
                                }
                            },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        letters.forEach { l ->
                            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                                Text(l, fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }

            if (searchPos == "Alt") {
                DrawerSearch(query, { query = it }, focus,
                    onEnter = { if (list.size == 1) onLaunch(list[0].packageName) },
                    onShortcut = { id -> onShortcut(id, query) })
            }
        }
    }

    val mApp = menuApp
    if (mApp != null) {
        val isLocked = mApp.packageName in UserData.locked
        val isHidden = mApp.packageName in UserData.hidden
        AlertDialog(
            onDismissRequest = { menuApp = null },
            title = { Text(mApp.label) },
            text = {
                Column {
                    MenuRow("Ana ekrana ekle") { onAddHome(mApp.packageName); menuApp = null }
                    MenuRow("Gruba ekle…") { groupPick = mApp; menuApp = null }
                    if (groupName != null) {
                        MenuRow("Gruptan çıkar") { UserData.removeFromGroup(groupName, mApp.packageName); menuApp = null }
                    }
                    if (hideOn) {
                        MenuRow(if (isHidden) "Göster" else "Gizle") { UserData.setHidden(mApp.packageName, !isHidden); menuApp = null }
                    }
                    MenuRow(if (isLocked) "Kilidi kaldır" else "Kilitle (ekran kilidi ister)") {
                        if (isLocked) {
                            requestAuth { UserData.setLocked(mApp.packageName, false) }
                        } else {
                            if (!Security.isDeviceSecure(context)) {
                                Toast.makeText(context, "Cihazda ekran kilidi yok; kilit etkisiz olur.", Toast.LENGTH_LONG).show()
                            }
                            UserData.setLocked(mApp.packageName, true)
                        }
                        menuApp = null
                    }
                    MenuRow("Uygulama bilgisi") { onAppInfo(mApp.packageName); menuApp = null }
                    MenuRow("Kaldır") { onUninstall(mApp.packageName); menuApp = null }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { menuApp = null }) { Text("Kapat") } }
        )
    }

    val gp = groupPick
    if (gp != null) {
        AlertDialog(
            onDismissRequest = { groupPick = null },
            title = { Text("Gruba ekle") },
            text = {
                Column {
                    groupNames.forEach { g ->
                        MenuRow(g) { UserData.addToGroup(g, gp.packageName); groupPick = null }
                    }
                    MenuRow("Yeni grup…") { newGroup = GroupRequest(gp); groupPick = null }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { groupPick = null }) { Text("İptal") } }
        )
    }

    val req = newGroup
    if (req != null) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { newGroup = null },
            title = { Text("Yeni grup") },
            text = {
                OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, placeholder = { Text("Grup adı") })
            },
            confirmButton = {
                TextButton(onClick = {
                    val n = name.trim()
                    if (n.isNotEmpty() && n !in UserData.groups) {
                        UserData.createGroup(n)
                        val target = req.app
                        if (target != null) UserData.addToGroup(n, target.packageName)
                        val idx = UserData.groups.keys.toList().indexOf(n)
                        if (idx >= 0) tab = (if (freqOn) 2 else 1) + idx
                        newGroup = null
                    }
                }) { Text("Oluştur") }
            },
            dismissButton = { TextButton(onClick = { newGroup = null }) { Text("İptal") } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DrawerTile(app: LaunchApp, dim: Boolean, locked: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    Column(
        Modifier.fillMaxWidth()
            .alpha(if (dim) 0.5f else 1f)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box {
            AppIcon(app, iconDp(48))
            if (locked) {
                Icon(
                    Icons.Default.Lock, null,
                    Modifier.size(14.dp).align(Alignment.BottomEnd),
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
        Text(
            app.label, style = MaterialTheme.typography.labelSmall, maxLines = 2,
            textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp, start = 2.dp, end = 2.dp)
        )
    }
}

@Composable
private fun DrawerSearch(
    query: String,
    onQuery: (String) -> Unit,
    focus: FocusRequester,
    onEnter: () -> Unit,
    onShortcut: (String) -> Unit
) {
    val colors = searchColors()
    val radius = Settings.int("searchRadius", 22).dp
    TextField(
        value = query,
        onValueChange = onQuery,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).focusRequester(focus),
        singleLine = true,
        placeholder = { Text("Uygulama ara") },
        leadingIcon = { Icon(Icons.Default.Search, null) },
        trailingIcon = {
            Row {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onQuery("") }) { Icon(Icons.Default.Close, "Temizle") }
                }
                SearchShortcuts.enabled().forEach { id ->
                    IconButton(onClick = { onShortcut(id) }) { Icon(SearchShortcuts.icon(id), SearchShortcuts.label(id)) }
                }
            }
        },
        shape = RoundedCornerShape(radius),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onEnter() }),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = colors.first,
            unfocusedContainerColor = colors.first,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            focusedTextColor = colors.second,
            unfocusedTextColor = colors.second
        )
    )
}
