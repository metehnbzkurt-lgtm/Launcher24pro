package com.example.materiallauncher

import android.app.KeyguardManager
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class LaunchApp(val label: String, val packageName: String, val activity: String)

/** type: "app" | "folder" | "widget" */
data class HomeItem(
    val id: String,
    val type: String,
    val page: Int,
    val col: Int,
    val row: Int,
    val spanX: Int = 1,
    val spanY: Int = 1,
    val pkg: String = "",
    val name: String = "",
    val members: List<String> = emptyList(),
    val widgetId: Int = -1
)

object HomeStore {
    const val MAX_PAGES = 8
    val items = mutableStateListOf<HomeItem>()
    var pages by mutableIntStateOf(1)
        private set

    // Widget eklerken aralık hesabı için HomeScreen tarafından güncellenir.
    var cellWpx = 0f
    var cellHpx = 0f
    var currentPage = 0

    fun newId(): String = java.util.UUID.randomUUID().toString().take(8)

    fun load() {
        items.clear()
        val s = Settings.prefs.getString("home_layout", "[]") ?: "[]"
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val m = ArrayList<String>()
                val ma = o.optJSONArray("members")
                if (ma != null) for (j in 0 until ma.length()) m.add(ma.getString(j))
                items.add(
                    HomeItem(
                        id = o.getString("id"), type = o.getString("type"),
                        page = o.getInt("page"), col = o.getInt("col"), row = o.getInt("row"),
                        spanX = o.optInt("sx", 1), spanY = o.optInt("sy", 1),
                        pkg = o.optString("pkg", ""), name = o.optString("name", ""),
                        members = m, widgetId = o.optInt("wid", -1)
                    )
                )
            }
        } catch (e: Exception) { }
        var p = Settings.prefs.getInt("home_pages", 1).coerceIn(1, MAX_PAGES)
        val maxPage = items.maxOfOrNull { it.page } ?: 0
        if (maxPage + 1 > p) p = (maxPage + 1).coerceAtMost(MAX_PAGES)
        pages = p
    }

    fun save() {
        val arr = JSONArray()
        for (item in items) {
            val o = JSONObject()
            o.put("id", item.id); o.put("type", item.type)
            o.put("page", item.page); o.put("col", item.col); o.put("row", item.row)
            o.put("sx", item.spanX); o.put("sy", item.spanY)
            o.put("pkg", item.pkg); o.put("name", item.name)
            o.put("members", JSONArray(item.members))
            o.put("wid", item.widgetId)
            arr.put(o)
        }
        Settings.prefs.edit().putString("home_layout", arr.toString()).putInt("home_pages", pages).apply()
    }

    private fun covers(item: HomeItem, page: Int, col: Int, row: Int): Boolean =
        item.page == page && col >= item.col && col < item.col + item.spanX &&
            row >= item.row && row < item.row + item.spanY

    fun itemAt(page: Int, col: Int, row: Int, excludeId: String?): HomeItem? =
        items.firstOrNull { it.id != excludeId && covers(it, page, col, row) }

    fun isFree(page: Int, col: Int, row: Int, sx: Int, sy: Int, cols: Int, rows: Int, excludeId: String?): Boolean {
        if (col < 0 || row < 0 || col + sx > cols || row + sy > rows) return false
        for (c in col until col + sx) for (r in row until row + sy) {
            if (itemAt(page, c, r, excludeId) != null) return false
        }
        return true
    }

    private fun findFree(sx: Int, sy: Int, cols: Int, rows: Int, preferred: Int): Triple<Int, Int, Int>? {
        val order = (0 until pages).sortedBy { if (it == preferred) -1 else it }
        for (p in order) for (r in 0..(rows - sy)) for (c in 0..(cols - sx)) {
            if (isFree(p, c, r, sx, sy, cols, rows, null)) return Triple(p, c, r)
        }
        return null
    }

    /** (sayfa, sütun, satır); yer yoksa ve sayfa sınırı aşılmadıysa yeni sayfa açar. */
    private fun allocateSpot(sx: Int, sy: Int, cols: Int, rows: Int, preferred: Int): Triple<Int, Int, Int>? {
        val spot = findFree(sx, sy, cols, rows, preferred)
        if (spot != null) return spot
        if (pages < MAX_PAGES) { pages++; return Triple(pages - 1, 0, 0) }
        return null
    }

    fun addApp(pkg: String, cols: Int, rows: Int, page: Int): Boolean {
        val spot = allocateSpot(1, 1, cols, rows, page) ?: return false
        items.add(HomeItem(newId(), "app", spot.first, spot.second, spot.third, pkg = pkg))
        save()
        return true
    }

    fun addAppAt(pkg: String, page: Int, col: Int, row: Int) {
        items.add(HomeItem(newId(), "app", page, col, row, pkg = pkg))
        save()
    }

    fun addWidget(widgetId: Int, sx: Int, sy: Int, cols: Int, rows: Int, page: Int): Boolean {
        val spot = allocateSpot(sx, sy, cols, rows, page) ?: return false
        items.add(HomeItem(newId(), "widget", spot.first, spot.second, spot.third, sx, sy, widgetId = widgetId))
        save()
        return true
    }

    fun update(item: HomeItem) {
        val i = items.indexOfFirst { it.id == item.id }
        if (i >= 0) { items[i] = item; save() }
    }

    fun remove(id: String): HomeItem? {
        val i = items.indexOfFirst { it.id == id }
        if (i < 0) return null
        val removed = items.removeAt(i)
        save()
        return removed
    }

    fun restore(item: HomeItem, cols: Int, rows: Int) {
        if (isFree(item.page, item.col, item.row, item.spanX, item.spanY, cols, rows, null)) {
            items.add(item)
        } else {
            val spot = allocateSpot(item.spanX, item.spanY, cols, rows, item.page) ?: return
            items.add(item.copy(page = spot.first, col = spot.second, row = spot.third))
        }
        save()
    }

    fun mergeIntoFolder(target: HomeItem, dragged: HomeItem) {
        items.removeAll { it.id == dragged.id }
        val i = items.indexOfFirst { it.id == target.id }
        if (i >= 0) {
            items[i] = target.copy(type = "folder", pkg = "", name = "Klasör", members = listOf(target.pkg, dragged.pkg))
        }
        save()
    }

    fun addToFolder(folderId: String, pkg: String, draggedId: String?) {
        val i = items.indexOfFirst { it.id == folderId }
        if (i < 0) return
        val f = items[i]
        if (pkg !in f.members) items[i] = f.copy(members = f.members + pkg)
        if (draggedId != null) items.removeAll { it.id == draggedId }
        save()
    }

    fun renameFolder(folderId: String, name: String) {
        val i = items.indexOfFirst { it.id == folderId }
        if (i >= 0) { items[i] = items[i].copy(name = name); save() }
    }

    fun removeFromFolder(folderId: String, pkg: String, toHome: Boolean, cols: Int, rows: Int) {
        val i = items.indexOfFirst { it.id == folderId }
        if (i < 0) return
        val f = items[i]
        val rest = f.members - pkg
        when {
            rest.isEmpty() -> items.removeAt(i)
            rest.size == 1 -> items[i] = f.copy(type = "app", pkg = rest[0], name = "", members = emptyList())
            else -> items[i] = f.copy(members = rest)
        }
        if (toHome) {
            val spot = allocateSpot(1, 1, cols, rows, f.page)
            if (spot != null) items.add(HomeItem(newId(), "app", spot.first, spot.second, spot.third, pkg = pkg))
        }
        save()
    }

    fun addPage(): Boolean {
        if (pages >= MAX_PAGES) return false
        pages++
        save()
        return true
    }

    fun trimTrailing(keep: Int) {
        while (pages > 1 && pages - 1 > keep && items.none { it.page == pages - 1 }) pages--
        save()
    }

    fun compactPages() {
        val used = items.map { it.page }.distinct().sorted()
        if (used.isEmpty()) { pages = 1; save(); return }
        val map = HashMap<Int, Int>()
        used.forEachIndexed { index, p -> map[p] = index }
        for (i in items.indices) items[i] = items[i].copy(page = map[items[i].page] ?: 0)
        pages = used.size.coerceAtLeast(1)
        save()
    }

    /** Kılavuz küçülürse dışarıda kalan öğeleri boş yerlere taşır. */
    fun fit(cols: Int, rows: Int) {
        val bad = items.filter { it.col + it.spanX > cols || it.row + it.spanY > rows }
        if (bad.isEmpty()) return
        items.removeAll(bad)
        for (b in bad) {
            val sx = b.spanX.coerceAtMost(cols)
            val sy = b.spanY.coerceAtMost(rows)
            val spot = allocateSpot(sx, sy, cols, rows, b.page)
            if (spot != null) {
                items.add(b.copy(page = spot.first, col = spot.second, row = spot.third, spanX = sx, spanY = sy))
            } else if (b.type == "widget") {
                WidgetHost.deleteId(b.widgetId)
            }
        }
        save()
    }

    /** Kaldırılmış uygulamaları ana ekrandan temizler. */
    fun purge(valid: Set<String>) {
        if (valid.isEmpty()) return
        var changed = false
        for (cur in items.toList()) {
            if (cur.type == "app" && cur.pkg !in valid) {
                items.removeAll { x -> x.id == cur.id }
                changed = true
            } else if (cur.type == "folder") {
                val m = cur.members.filter { p -> p in valid }
                if (m.size != cur.members.size) {
                    changed = true
                    val idx = items.indexOfFirst { x -> x.id == cur.id }
                    if (idx >= 0) {
                        when {
                            m.isEmpty() -> items.removeAt(idx)
                            m.size == 1 -> items[idx] = cur.copy(type = "app", pkg = m[0], name = "", members = emptyList())
                            else -> items[idx] = cur.copy(members = m)
                        }
                    }
                }
            }
        }
        if (changed) save()
    }

    fun reset() {
        for (w in items.filter { it.type == "widget" }) WidgetHost.deleteId(w.widgetId)
        items.clear()
        pages = 1
        save()
    }
}

/** Uygulama menüsü grupları, gizli/kilitli uygulamalar ve kullanım sayıları. */
object UserData {
    var groups by mutableStateOf<Map<String, List<String>>>(emptyMap())
        private set
    var hidden by mutableStateOf<Set<String>>(emptySet())
        private set
    var locked by mutableStateOf<Set<String>>(emptySet())
        private set
    private var usage: MutableMap<String, Int> = HashMap()

    private fun readSet(key: String): Set<String> {
        val out = HashSet<String>()
        try {
            val a = JSONArray(Settings.prefs.getString(key, "[]") ?: "[]")
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) { }
        return out
    }

    fun load() {
        val m = LinkedHashMap<String, List<String>>()
        try {
            val g = JSONObject(Settings.prefs.getString("drawer_groups", "{}") ?: "{}")
            val keys = g.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val a = g.getJSONArray(k)
                val l = ArrayList<String>()
                for (i in 0 until a.length()) l.add(a.getString(i))
                m[k] = l
            }
        } catch (e: Exception) { }
        groups = m
        hidden = readSet("hidden_apps")
        locked = readSet("locked_apps")
        val u = HashMap<String, Int>()
        try {
            val o = JSONObject(Settings.prefs.getString("usage_counts", "{}") ?: "{}")
            val keys = o.keys()
            while (keys.hasNext()) { val k = keys.next(); u[k] = o.getInt(k) }
        } catch (e: Exception) { }
        usage = u
    }

    private fun saveGroups() {
        val o = JSONObject()
        for ((k, v) in groups) o.put(k, JSONArray(v))
        Settings.prefs.edit().putString("drawer_groups", o.toString()).apply()
    }

    fun createGroup(name: String) { groups = groups + (name to emptyList<String>()); saveGroups() }

    fun deleteGroup(name: String) { groups = groups - name; saveGroups() }

    fun addToGroup(name: String, pkg: String) {
        val cur = groups[name] ?: return
        if (pkg !in cur) { groups = groups + (name to (cur + pkg)); saveGroups() }
    }

    fun removeFromGroup(name: String, pkg: String) {
        val cur = groups[name] ?: return
        groups = groups + (name to (cur - pkg))
        saveGroups()
    }

    fun setHidden(pkg: String, on: Boolean) {
        hidden = if (on) hidden + pkg else hidden - pkg
        Settings.prefs.edit().putString("hidden_apps", JSONArray(hidden.toList()).toString()).apply()
    }

    fun setLocked(pkg: String, on: Boolean) {
        locked = if (on) locked + pkg else locked - pkg
        Settings.prefs.edit().putString("locked_apps", JSONArray(locked.toList()).toString()).apply()
    }

    fun bump(pkg: String) {
        usage[pkg] = (usage[pkg] ?: 0) + 1
        val o = JSONObject()
        for ((k, v) in usage) o.put(k, v)
        Settings.prefs.edit().putString("usage_counts", o.toString()).apply()
    }

    fun frequent(): List<String> =
        usage.entries.sortedByDescending { it.value }.take(8).map { it.key }
}

/** Uygulama kilidi, cihazın kendi ekran kilidi (PIN/desen/parmak izi) ile doğrulanır; launcher kendi parolasını tutmaz. */
object Security {
    private var unlockedUntil = 0L
    fun recentlyUnlocked(): Boolean = System.currentTimeMillis() < unlockedUntil
    fun markUnlocked() { unlockedUntil = System.currentTimeMillis() + 30_000L }
    fun isDeviceSecure(context: Context): Boolean =
        context.getSystemService(KeyguardManager::class.java)?.isDeviceSecure == true
}
