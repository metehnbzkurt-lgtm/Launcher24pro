package com.example.materiallauncher

import org.json.JSONArray
import org.json.JSONObject

/** Tüm ayarlar + ana ekran düzeni + gruplar/gizli/kilitli listeleri tek JSON dosyasına yazılır. */
object Backup {
    fun export(): String {
        val root = JSONObject()
        root.put("app", "MaterialLauncher")
        root.put("version", 1)
        val arr = JSONArray()
        for ((k, v) in Settings.prefs.all) {
            val o = JSONObject()
            o.put("k", k)
            if (v is Boolean) { o.put("t", "b"); o.put("v", v) }
            else if (v is Int) { o.put("t", "i"); o.put("v", v) }
            else if (v is Long) { o.put("t", "l"); o.put("v", v) }
            else if (v is Float) { o.put("t", "f"); o.put("v", v.toDouble()) }
            else if (v is String) { o.put("t", "s"); o.put("v", v) }
            else if (v is Set<*>) {
                o.put("t", "ss")
                val sa = JSONArray()
                for (e in v) sa.put(e.toString())
                o.put("v", sa)
            } else continue
            arr.put(o)
        }
        root.put("prefs", arr)
        return root.toString(2)
    }

    /** Başarılıysa true. Widget'lar cihaza özgü olduğu için geri yüklenmez. */
    fun import(json: String): Boolean {
        try {
            val root = JSONObject(json)
            if (root.optString("app") != "MaterialLauncher") return false
            val arr = root.getJSONArray("prefs")
            for (w in HomeStore.items.filter { it.type == "widget" }) WidgetHost.deleteId(w.widgetId)
            val edit = Settings.prefs.edit()
            edit.clear()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val k = o.getString("k")
                when (o.getString("t")) {
                    "b" -> edit.putBoolean(k, o.getBoolean("v"))
                    "i" -> edit.putInt(k, o.getInt("v"))
                    "l" -> edit.putLong(k, o.getLong("v"))
                    "f" -> edit.putFloat(k, o.getDouble("v").toFloat())
                    "s" -> {
                        var s = o.getString("v")
                        if (k == "home_layout") s = stripWidgets(s)
                        edit.putString(k, s)
                    }
                    "ss" -> {
                        val a = o.getJSONArray("v")
                        val set = HashSet<String>()
                        for (j in 0 until a.length()) set.add(a.getString(j))
                        edit.putStringSet(k, set)
                    }
                }
            }
            edit.commit()
            Settings.notifyChanged()
            HomeStore.load()
            UserData.load()
            return true
        } catch (e: Exception) {
            return false
        }
    }

    private fun stripWidgets(layout: String): String {
        val src = JSONArray(layout)
        val out = JSONArray()
        for (i in 0 until src.length()) {
            val o = src.getJSONObject(i)
            if (o.optString("type") != "widget") out.put(o)
        }
        return out.toString()
    }
}
