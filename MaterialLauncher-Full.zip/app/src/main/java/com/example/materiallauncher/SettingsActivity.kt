package com.example.materiallauncher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Settings.init(this)
        UserData.load()
        HomeStore.load()
        WidgetHost.init(this)
        enableEdgeToEdge()
        setContent { LauncherTheme { SettingsScreen() } }
    }
}

private val gestureOptions = listOf("Yok", "Uygulama menüsü", "Arama", "Ayarlar", "Ekranı kilitle", "Bildirimleri aç", "Son uygulamalar")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var confirmReset by remember { mutableStateOf(false) }
    var packDialog by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { it.write(Backup.export().toByteArray(Charsets.UTF_8)) }
                Toast.makeText(context, "Yedek kaydedildi", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Yedek yazılamadı", Toast.LENGTH_SHORT).show()
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                val ok = Backup.import(text)
                Toast.makeText(
                    context,
                    if (ok) "Geri yüklendi (widget'lar yeniden eklenmelidir)" else "Geçersiz yedek dosyası",
                    Toast.LENGTH_LONG
                ).show()
                if (ok) scope.launch { AppRepo.applyIconPack(context) }
            } catch (e: Exception) {
                Toast.makeText(context, "Dosya okunamadı", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Launcher ayarları") }) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {

            Section("1. Ana ekran")
            IntSlider("Simge boyutu", "iconScale", 100, 75, 150, "%")
            ChoiceSetting("Ana ekran kılavuzu", "homeGrid", listOf("4×5", "4×6", "5×5", "5×6", "6×6"), "5×5")
            ChoiceSetting("Arama çubuğu yeri", "homeSearch", listOf("Hiçbiri", "Üst", "Alt"), "Alt")
            ToggleSetting("Uygulama etiketlerini göster", "homeLabels", true)
            ToggleSetting("Duvar kâğıdı kaydırma", "wallpaperScroll", true)
            ChoiceSetting("Sayfa göstergesi", "pageIndicator", listOf("Hiçbiri", "Noktalar", "Çizgi"), "Noktalar")
            ToggleSetting("Bırakma hedefleri (Kaldır / Bilgi)", "dropTargets", true)
            ToggleSetting("Geri alma çubuğunu göster", "undoBar", true)
            ToggleSetting("Ana ekranı döndürmeye izin ver", "rotateHome", false)
            OutlinedButton(onClick = { confirmReset = true }) { Text("Ana ekran düzenini sıfırla") }
            Divider2()

            Section("2. Uygulama menüsü")
            ChoiceSetting("Menü kılavuzu (sütun)", "drawerGrid", listOf("4×5", "5×5", "6×5", "6×6"), "5×5")
            ChoiceSetting("Geçiş animasyonu", "drawerAnimation", listOf("Yukarı kaydır", "Sol", "Solma", "Yok"), "Yukarı kaydır")
            ChoiceSetting("Arama çubuğu yeri", "drawerSearch", listOf("Üst", "Alt", "Hiçbiri"), "Alt")
            ToggleSetting("Sık kullanılanlar sekmesi", "frequentApps", true)
            ToggleSetting("Hızlı kaydırma çubuğu", "fastScroll", true)
            ToggleSetting("Gizli uygulamalar (göz simgesi)", "hideApps", true)
            Note("Gruplar: menüdeki + düğmesiyle oluşturulur; bir uygulamaya uzun basıp \"Gruba ekle\" seçilir.")
            Divider2()

            Section("3. Arama çubuğu")
            ChoiceSetting("Renk", "searchColor", listOf("Yüzey", "Birincil", "İkincil", "Üçüncül"), "Yüzey")
            IntSlider("Şeffaflık", "searchTransparency", 0, 0, 100, "%")
            IntSlider("Köşe yarıçapı", "searchRadius", 22, 0, 40, " dp")
            ToggleSetting("Gölge", "searchShadow", false)
            Text("Kısayollar (sırala ve aç/kapat)", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 8.dp))
            ShortcutSettings()
            Divider2()

            Section("4. Klasörler")
            IntSlider("Klasör köşe yarıçapı", "folderRadius", 40, 0, 40, " dp")
            ChoiceSetting("Klasör kılavuzu", "folderGrid", listOf("AUTO", "3×3", "4×4", "5×5"), "AUTO")
            ChoiceSetting("Kaydırma yönü", "folderScroll", listOf("Yatay", "Dikey"), "Yatay")
            ToggleSetting("Canlı önizleme", "folderLivePreview", true)
            ToggleSetting("Klasör adını ana ekranda göster", "folderName", true)
            Note("Klasör oluşturmak için bir simgeyi başka bir simgenin üstüne sürükleyip bırakın.")
            Divider2()

            Section("5. Görünüm")
            ChoiceSetting("Arayüz teması", "theme", listOf("Sistem", "Açık", "Koyu", "Dinamik renk"), "Dinamik renk")
            ChoiceSetting("Simge şekli", "iconShape", listOf("Sistem", "Yuvarlak", "Yuvarlatılmış kare", "Kare", "Gözyaşı"), "Sistem")
            val currentPack = Settings.str("iconPack", "")
            Text("Simge paketi", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 8.dp))
            OutlinedButton(onClick = { packDialog = true }) { Text(if (currentPack.isEmpty()) "Varsayılan" else currentPack) }
            ToggleSetting("Geçiş animasyonlarını kapat", "disableAnimations", false)
            ToggleSetting("Durum çubuğunu göster", "statusBar", true)
            ChoiceSetting("Durum çubuğu simgeleri", "statusIcons", listOf("Otomatik", "Açık", "Koyu"), "Otomatik")
            Divider2()

            Section("6. Hareketler")
            ChoiceSetting("Yukarı kaydırma", "gestureSwipeUp", gestureOptions, "Uygulama menüsü")
            ChoiceSetting("Aşağı kaydırma", "gestureSwipeDown", gestureOptions, "Yok")
            ChoiceSetting("Boş alanda çift dokunma", "gestureDoubleTap", gestureOptions, "Yok")
            Note("\"Ekranı kilitle\", \"Bildirimleri aç\" ve \"Son uygulamalar\" için Erişilebilirlik'te \"Material Launcher hareketleri\" hizmetini açmanız gerekir. Hizmet ekran içeriğini okumaz; yalnızca bu genel eylemleri çağırır.")
            OutlinedButton(onClick = {
                try { context.startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (e: Exception) { }
            }) { Text("Erişilebilirlik ayarlarını aç") }
            Divider2()

            Section("7. Güvenlik")
            Text("Kilitli uygulama: ${UserData.locked.size} · Gizli uygulama: ${UserData.hidden.size}")
            Note("Uygulama kilidi ve gizli uygulamalar, cihazın kendi ekran kilidi (PIN / desen / parmak izi) ile doğrulanır; launcher kendi parolasını saklamaz. Uygulama menüsünde bir uygulamaya uzun basarak kilitleyebilir veya gizleyebilirsiniz. Bu koruma yalnızca bu launcher içindir; uygulamalar başka yollarla açılabilir.")
            Divider2()

            Section("8. Yedekleme")
            Note("Ayarlar, ana ekran düzeni, klasörler ve gruplar tek bir JSON dosyasına yazılır. Widget'lar cihaza özgü olduğundan geri yüklemede yeniden eklenmelidir.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { exportLauncher.launch("materiallauncher-yedek.json") }) { Text("Dışa aktar") }
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) }) { Text("İçe aktar") }
            }
            Spacer(Modifier.height(32.dp))
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Ana ekranı sıfırla") },
            text = { Text("Tüm simgeler, klasörler ve widget'lar ana ekrandan kaldırılır. Ayarlar korunur.") },
            confirmButton = { TextButton(onClick = { HomeStore.reset(); confirmReset = false }) { Text("Sıfırla") } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("İptal") } }
        )
    }

    if (packDialog) {
        val packs = remember { AppRepo.iconPacks(context) }
        AlertDialog(
            onDismissRequest = { packDialog = false },
            title = { Text("Simge paketi") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    MenuRow("Varsayılan (sistem simgeleri)") {
                        Settings.putStr("iconPack", "")
                        scope.launch { AppRepo.applyIconPack(context) }
                        packDialog = false
                    }
                    packs.forEach { p ->
                        MenuRow(p.first) {
                            Settings.putStr("iconPack", p.second)
                            scope.launch { AppRepo.applyIconPack(context) }
                            packDialog = false
                        }
                    }
                    if (packs.isEmpty()) Note("Yüklü ADW/Nova uyumlu simge paketi bulunamadı.")
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { packDialog = false }) { Text("Kapat") } }
        )
    }
}

@Composable
private fun Section(title: String) {
    Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(bottom = 4.dp))
}

@Composable
private fun Divider2() {
    HorizontalDivider(Modifier.padding(vertical = 14.dp))
}

@Composable
private fun Note(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(vertical = 4.dp)
    )
}

@Composable
private fun ToggleSetting(title: String, key: String, default: Boolean) {
    var checked by remember(key) { mutableStateOf(Settings.bool(key, default)) }
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, modifier = Modifier.weight(1f).padding(end = 12.dp))
        Switch(checked = checked, onCheckedChange = { checked = it; Settings.putBool(key, it) })
    }
}

@Composable
private fun ChoiceSetting(title: String, key: String, options: List<String>, default: String) {
    var selected by remember(key) { mutableStateOf(Settings.str(key, default)) }
    var expanded by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Column {
            OutlinedButton(onClick = { expanded = true }) { Text(selected) }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option) },
                        onClick = { selected = option; Settings.putStr(key, option); expanded = false }
                    )
                }
            }
        }
    }
}

@Composable
private fun IntSlider(title: String, key: String, def: Int, min: Int, max: Int, unit: String) {
    var v by remember(key) { mutableFloatStateOf(Settings.int(key, def).toFloat().coerceIn(min.toFloat(), max.toFloat())) }
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title)
            Text("${v.toInt()}$unit", color = MaterialTheme.colorScheme.primary)
        }
        Slider(
            value = v,
            onValueChange = { v = it },
            onValueChangeFinished = { Settings.putInt(key, v.toInt()) },
            valueRange = min.toFloat()..max.toFloat()
        )
    }
}

@Composable
private fun ShortcutSettings() {
    var order by remember { mutableStateOf(SearchShortcuts.order()) }
    order.forEachIndexed { i, id ->
        var on by remember(id) { mutableStateOf(Settings.bool(SearchShortcuts.key(id), SearchShortcuts.default(id))) }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(SearchShortcuts.icon(id), null)
            Spacer(Modifier.width(12.dp))
            Text(SearchShortcuts.label(id), Modifier.weight(1f))
            TextButton(onClick = { SearchShortcuts.move(id, -1); order = SearchShortcuts.order() }, enabled = i > 0) { Text("▲") }
            TextButton(onClick = { SearchShortcuts.move(id, 1); order = SearchShortcuts.order() }, enabled = i < order.lastIndex) { Text("▼") }
            Switch(checked = on, onCheckedChange = { on = it; Settings.putBool(SearchShortcuts.key(id), it) })
        }
    }
}
