package com.example.materiallauncher

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * İsteğe bağlı. Yalnızca "ekranı kilitle / bildirimleri aç / son uygulamalar" hareketleri için
 * genel eylem (performGlobalAction) çağırır. Ekran içeriğini okumaz.
 */
class LauncherAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: LauncherAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}
}
