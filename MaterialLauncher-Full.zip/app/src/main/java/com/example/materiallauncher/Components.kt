package com.example.materiallauncher

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

fun iconShape(): Shape = when (Settings.str("iconShape", "Sistem")) {
    "Yuvarlak" -> CircleShape
    "Yuvarlatılmış kare" -> RoundedCornerShape(28)
    "Kare" -> RoundedCornerShape(8.dp)
    "Gözyaşı" -> RoundedCornerShape(topStartPercent = 50, topEndPercent = 50, bottomEndPercent = 50, bottomStartPercent = 12)
    else -> RectangleShape
}

/** Simge boyutu ayarına (%) göre ölçeklenmiş dp. */
fun iconDp(base: Int): Dp = (base * Settings.int("iconScale", 100) / 100f).dp

@Composable
fun AppIcon(app: LaunchApp, size: Dp, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val version = AppRepo.iconVersion
    val bmp by produceState<ImageBitmap?>(AppRepo.peek(app.packageName), app.packageName, version) {
        value = AppRepo.iconFor(context, app)
    }
    val shape = iconShape()
    val b = bmp
    if (b != null) {
        Image(bitmap = b, contentDescription = null, modifier = modifier.size(size).clip(shape))
    } else {
        Box(modifier.size(size).clip(shape).background(MaterialTheme.colorScheme.surfaceVariant))
    }
}

@Composable
fun HomeLabel(text: String) {
    Text(
        text,
        modifier = Modifier.padding(top = 2.dp),
        color = Color.White,
        fontSize = 11.sp,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Center,
        style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.6f), Offset(0f, 1f), 4f))
    )
}

@Composable
fun FolderIcon(item: HomeItem, size: Dp) {
    val s = iconShape()
    val shape: Shape = if (s === RectangleShape) RoundedCornerShape(30) else s
    Box(
        Modifier.size(size).clip(shape).background(Color.White.copy(alpha = 0.28f)),
        contentAlignment = Alignment.Center
    ) {
        val apps = item.members.mapNotNull { AppRepo.index[it] }.take(4)
        if (Settings.bool("folderLivePreview", true) && apps.isNotEmpty()) {
            val mini = size * 0.38f
            val gap = size * 0.04f
            Column(verticalArrangement = Arrangement.spacedBy(gap)) {
                apps.chunked(2).forEach { rowApps ->
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        rowApps.forEach { AppIcon(it, mini) }
                    }
                }
            }
        } else {
            Icon(Icons.Default.Folder, null, tint = Color.White)
        }
    }
}

@Composable
fun MenuRow(text: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Text(text, Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
    }
}

/** Arama çubuğu kısayolları: sıralanabilir ve tek tek açılıp kapatılabilir. */
object SearchShortcuts {
    val all = listOf("voice", "playstore", "web", "weather")

    fun label(id: String): String = when (id) {
        "voice" -> "Sesli arama"
        "playstore" -> "Play Store"
        "web" -> "Web'de ara"
        else -> "Hava durumu"
    }

    fun icon(id: String): ImageVector = when (id) {
        "voice" -> Icons.Default.Mic
        "playstore" -> Icons.Default.Store
        "web" -> Icons.Default.Public
        else -> Icons.Default.WbSunny
    }

    fun key(id: String): String = when (id) {
        "voice" -> "searchVoice"
        "playstore" -> "searchPlayStore"
        "web" -> "searchWeb"
        else -> "searchWeather"
    }

    fun default(id: String): Boolean = id == "voice" || id == "playstore"

    fun order(): List<String> {
        val saved = Settings.str("searchOrder", all.joinToString(",")).split(",").filter { it in all }
        return saved + all.filter { it !in saved }
    }

    fun enabled(): List<String> = order().filter { Settings.bool(key(it), default(it)) }

    fun move(id: String, delta: Int) {
        val l = order().toMutableList()
        val i = l.indexOf(id)
        val j = i + delta
        if (i < 0 || j < 0 || j >= l.size) return
        l.removeAt(i)
        l.add(j, id)
        Settings.putStr("searchOrder", l.joinToString(","))
    }
}

/** (arka plan, içerik) rengi: seçilen renk ve şeffaflık ayarına göre. */
@Composable
fun searchColors(): Pair<Color, Color> {
    val cs = MaterialTheme.colorScheme
    val alpha = 1f - Settings.int("searchTransparency", 0) / 100f
    val pair = when (Settings.str("searchColor", "Yüzey")) {
        "Birincil" -> Pair(cs.primaryContainer, cs.onPrimaryContainer)
        "İkincil" -> Pair(cs.secondaryContainer, cs.onSecondaryContainer)
        "Üçüncül" -> Pair(cs.tertiaryContainer, cs.onTertiaryContainer)
        else -> Pair(cs.surfaceContainerHigh, cs.onSurface)
    }
    return Pair(pair.first.copy(alpha = alpha), pair.second)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchPill(modifier: Modifier = Modifier, onClick: () -> Unit, onShortcut: (String) -> Unit) {
    val colors = searchColors()
    val radius = Settings.int("searchRadius", 22).dp
    Surface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(radius),
        color = colors.first,
        contentColor = colors.second,
        shadowElevation = if (Settings.bool("searchShadow", false)) 6.dp else 0.dp
    ) {
        Row(
            Modifier.padding(start = 16.dp, end = 4.dp).height(48.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Search, null)
            Spacer(Modifier.width(12.dp))
            Text("Ara", Modifier.weight(1f))
            SearchShortcuts.enabled().forEach { id ->
                IconButton(onClick = { onShortcut(id) }) { Icon(SearchShortcuts.icon(id), SearchShortcuts.label(id)) }
            }
        }
    }
}
