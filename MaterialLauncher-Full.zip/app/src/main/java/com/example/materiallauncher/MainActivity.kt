package com.example.materiallauncher

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import kotlin.math.ceil
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private companion object {
        const val REQ_BIND = 101
        const val REQ_CONFIG = 102
    }

    private val homeSignal = mutableIntStateOf(0)
    private var pendingAuth: (() -> Unit)? = null
    private var pendingWidgetId = -1
    private var pendingInfo: AppWidgetProviderInfo? = null

    private val authLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = pendingAuth
        pendingAuth = null
        if (r.resultCode == RESULT_OK) {
            Security.markUnlocked()
            cb?.invoke()
        }
    }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { reloadApps() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Settings.init(this)
        HomeStore.load()
        UserData.load()
        WidgetHost.init(this)
        enableEdgeToEdge()

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        reloadApps(first = true)
        setContent { LauncherTheme { Root() } }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(packageReceiver) } catch (e: Exception) { }
    }

    override fun onStart() {
        super.onStart()
        try { WidgetHost.host.startListening() } catch (e: Exception) { }
    }

    override fun onStop() {
        super.onStop()
        try { WidgetHost.host.stopListening() } catch (e: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        requestedOrientation = if (Settings.bool("rotateHome", false))
            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        else android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (Settings.bool("statusBar", true)) controller.show(WindowInsetsCompat.Type.statusBars())
        else controller.hide(WindowInsetsCompat.Type.statusBars())
        when (Settings.str("statusIcons", "Otomatik")) {
            "Koyu" -> controller.isAppearanceLightStatusBars = true
            "Açık" -> controller.isAppearanceLightStatusBars = false
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            homeSignal.intValue = homeSignal.intValue + 1
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun reloadApps(first: Boolean = false) {
        lifecycleScope.launch {
            AppRepo.load(this@MainActivity)
            if (first) AppRepo.applyIconPack(this@MainActivity)
            HomeStore.purge(AppRepo.index.keys)
            if (first) seedHome()
        }
    }

    /** İlk açılışta telefon, kamera, tarayıcı gibi temel uygulamaları alt satıra yerleştirir. */
    private fun seedHome() {
        if (Settings.prefs.getBoolean("seeded", false) || HomeStore.items.isNotEmpty()) return
        if (AppRepo.index.isEmpty()) return
        val pm = packageManager
        val probes = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)
        )
        val grid = Settings.grid("homeGrid", "5×5")
        val seen = HashSet<String>()
        var col = 0
        for (probe in probes) {
            if (col >= grid.first) break
            val pkg = pm.resolveActivity(probe, 0)?.activityInfo?.packageName ?: continue
            if (AppRepo.index.containsKey(pkg) && seen.add(pkg)) {
                HomeStore.addAppAt(pkg, 0, col, grid.second - 1)
                col++
            }
        }
        Settings.prefs.edit().putBoolean("seeded", true).apply()
    }

    // ---- Kimlik doğrulama: cihazın kendi ekran kilidi ----
    private fun requestAuth(onOk: () -> Unit) {
        if (Security.recentlyUnlocked()) { onOk(); return }
        val km = getSystemService(KeyguardManager::class.java)
        if (km == null || !km.isDeviceSecure) { onOk(); return }
        val i = km.createConfirmDeviceCredentialIntent("Kimlik doğrulama", "Devam etmek için ekran kilidinizi kullanın")
        if (i == null) { onOk(); return }
        pendingAuth = onOk
        authLauncher.launch(i)
    }

    private fun launchPkg(pkg: String) {
        val go: () -> Unit = {
            UserData.bump(pkg)
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) {
                try { startActivity(i) } catch (e: Exception) { toast("Uygulama açılamadı") }
            }
        }
        if (UserData.locked.contains(pkg)) requestAuth(go) else go()
    }

    private fun openAppInfo(pkg: String) {
        try {
            startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
        } catch (e: Exception) { toast("Açılamadı") }
    }

    private fun uninstall(pkg: String) {
        try { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))) } catch (e: Exception) { toast("Kaldırılamadı") }
    }

    private fun a11yAction(action: Int, minSdk: Int) {
        if (Build.VERSION.SDK_INT < minSdk) { toast("Bu hareket Android $minSdk ve üzerini ister"); return }
        val s = LauncherAccessibilityService.instance
        if (s == null) {
            toast("Önce Erişilebilirlik > Material Launcher hareketleri hizmetini açın")
            try { startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (e: Exception) { }
        } else {
            s.performGlobalAction(action)
        }
    }

    // ---- Widget ekleme akışı: bağla → (gerekirse) yapılandır → ana ekrana yerleştir ----
    @Suppress("DEPRECATION")
    private fun startAddWidget(info: AppWidgetProviderInfo) {
        val id = WidgetHost.host.allocateAppWidgetId()
        pendingWidgetId = id
        pendingInfo = info
        if (WidgetHost.manager.bindAppWidgetIdIfAllowed(id, info.provider)) {
            afterBind()
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            try {
                startActivityForResult(i, REQ_BIND)
            } catch (e: Exception) { cancelWidget() }
        }
    }

    private fun afterBind() {
        val info = pendingInfo ?: return
        if (info.configure != null) {
            try {
                WidgetHost.host.startAppWidgetConfigureActivityForResult(this, pendingWidgetId, 0, REQ_CONFIG, null)
            } catch (e: Exception) { finishWidget() }
        } else {
            finishWidget()
        }
    }

    private fun finishWidget() {
        val info = pendingInfo ?: return
        val id = pendingWidgetId
        pendingInfo = null
        pendingWidgetId = -1
        val grid = Settings.grid("homeGrid", "5×5")
        val d = resources.displayMetrics.density
        val cellW = if (HomeStore.cellWpx > 1f) HomeStore.cellWpx / d else 72f
        val cellH = if (HomeStore.cellHpx > 1f) HomeStore.cellHpx / d else 90f
        val sx = ceil(info.minWidth / cellW).toInt().coerceIn(1, grid.first)
        val sy = ceil(info.minHeight / cellH).toInt().coerceIn(1, grid.second)
        if (!HomeStore.addWidget(id, sx, sy, grid.first, grid.second, HomeStore.currentPage)) {
            WidgetHost.deleteId(id)
            toast("Ana ekranda yeterli boş alan yok")
        }
    }

    private fun cancelWidget() {
        WidgetHost.deleteId(pendingWidgetId)
        pendingWidgetId = -1
        pendingInfo = null
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_BIND -> if (resultCode == RESULT_OK) afterBind() else cancelWidget()
            REQ_CONFIG -> if (resultCode == RESULT_OK) finishWidget() else cancelWidget()
        }
    }

    // ---- Arayüz ----
    private fun drawerEnter(): EnterTransition {
        if (Settings.bool("disableAnimations", false)) return EnterTransition.None
        return when (Settings.str("drawerAnimation", "Yukarı kaydır")) {
            "Sol" -> slideInHorizontally { -it } + fadeIn()
            "Solma" -> fadeIn()
            "Yok" -> EnterTransition.None
            else -> slideInVertically { it / 2 } + fadeIn()
        }
    }

    private fun drawerExit(): ExitTransition {
        if (Settings.bool("disableAnimations", false)) return ExitTransition.None
        return when (Settings.str("drawerAnimation", "Yukarı kaydır")) {
            "Sol" -> slideOutHorizontally { -it } + fadeOut()
            "Solma" -> fadeOut()
            "Yok" -> ExitTransition.None
            else -> slideOutVertically { it / 2 } + fadeOut()
        }
    }

    @Composable
    private fun Root() {
        var drawerOpen by remember { mutableStateOf(false) }
        var focusSearch by remember { mutableStateOf(false) }
        var query by remember { mutableStateOf("") }
        var pickWidget by remember { mutableStateOf(false) }
        val snackbar = remember { SnackbarHostState() }
        val signal = homeSignal.intValue
        LaunchedEffect(signal) { if (signal > 0) drawerOpen = false }

        val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (r.resultCode == RESULT_OK && text != null) {
                query = text
                focusSearch = false
                drawerOpen = true
            }
        }

        fun shortcut(id: String, q: String) {
            try {
                when (id) {
                    "voice" -> voice.launch(
                        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Konuşun")
                    )
                    "playstore" -> {
                        if (q.isNotBlank()) {
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(q))))
                        } else {
                            val i = packageManager.getLaunchIntentForPackage("com.android.vending")
                            if (i != null) startActivity(i) else toast("Play Store bulunamadı")
                        }
                    }
                    "web" -> {
                        val term = if (q.isBlank()) "" else Uri.encode(q)
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$term")))
                    }
                    else -> startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode("hava durumu"))))
                }
            } catch (e: ActivityNotFoundException) {
                toast("Bu işlem için uygulama bulunamadı")
            }
        }

        fun runAction(a: String) {
            when (a) {
                "Uygulama menüsü" -> { focusSearch = false; query = ""; drawerOpen = true }
                "Arama" -> { focusSearch = true; query = ""; drawerOpen = true }
                "Ayarlar" -> startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
                "Ekranı kilitle" -> a11yAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, 28)
                "Bildirimleri aç" -> a11yAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, 26)
                "Son uygulamalar" -> a11yAction(AccessibilityService.GLOBAL_ACTION_RECENTS, 26)
            }
        }

        Box(Modifier.fillMaxSize()) {
            HomeScreen(
                snackbar = snackbar,
                homeSignal = signal,
                onLaunch = { launchPkg(it) },
                onGesture = { runAction(it) },
                onOpenSearch = { query = ""; focusSearch = true; drawerOpen = true },
                onShortcut = { shortcut(it, "") },
                onAddWidget = { pickWidget = true },
                onSettings = { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) },
                onWallpaper = {
                    try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Duvar kâğıdı")) }
                    catch (e: Exception) { toast("Duvar kâğıdı seçici bulunamadı") }
                },
                onAppInfo = { openAppInfo(it) }
            )

            AnimatedVisibility(visible = drawerOpen, enter = drawerEnter(), exit = drawerExit()) {
                AppDrawer(
                    initialQuery = query,
                    focusSearch = focusSearch,
                    onClose = { drawerOpen = false; query = "" },
                    onLaunch = { pkg -> drawerOpen = false; launchPkg(pkg) },
                    onAddHome = { pkg ->
                        val grid = Settings.grid("homeGrid", "5×5")
                        val ok = HomeStore.addApp(pkg, grid.first, grid.second, HomeStore.currentPage)
                        toast(if (ok) "Ana ekrana eklendi" else "Ana ekranda yer yok")
                    },
                    onSettings = { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) },
                    onShortcut = { id, q -> shortcut(id, q) },
                    onAppInfo = { openAppInfo(it) },
                    onUninstall = { uninstall(it) },
                    requestAuth = { cb -> requestAuth(cb) }
                )
            }

            SnackbarHost(
                snackbar,
                Modifier.align(Alignment.BottomCenter).windowInsetsPadding(WindowInsets.navigationBars).padding(bottom = 96.dp)
            )

            if (pickWidget) {
                WidgetPickerDialog(
                    onPick = { info -> pickWidget = false; startAddWidget(info) },
                    onDismiss = { pickWidget = false }
                )
            }
        }
    }
}
