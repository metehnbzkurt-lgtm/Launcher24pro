package com.example.materiallauncher

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val mode = Settings.str("theme", "Dinamik renk")
    val dark = when (mode) {
        "Açık" -> false
        "Koyu" -> true
        else -> isSystemInDarkTheme()
    }
    val scheme = if (mode == "Dinamik renk" && Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else {
        if (dark) darkColorScheme() else lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
