# Material Launcher 1.0 (tam sürüm)

Jetpack Compose + Material 3 tabanlı, Türkçe arayüzlü Android launcher.

## GitHub ile derleme
1. Yeni bir depo oluşturun ve bu klasörün **içeriğini** yükleyin (ZIP'in kendisini değil).
2. `Actions` > **Build Android APK** > *Run workflow*.
3. İş bitince **Artifacts** bölümünden `MaterialLauncher-release-apk` (veya debug) dosyasını indirin.
4. İsteğe bağlı: `v1.0.0` gibi bir etiket (tag) iterseniz APK otomatik GitHub Release'e eklenir.
5. Telefonda: Ayarlar > Uygulamalar > Varsayılan uygulamalar > Ana ekran uygulaması.

Release APK, kurulabilmesi için debug anahtarıyla imzalanır. Mağaza yayını için kendi keystore'unuzu `app/build.gradle.kts` içine tanımlayın.

## Özellikler
| Bölüm | Durum |
|---|---|
| Ana ekran | Uzun bas + sürükle-bırak, kalıcı yerleşim, çoklu sayfa (kenarda bekleyince yeni sayfa), duvar kâğıdı kaydırma, sayfa göstergesi, Kaldır/Bilgi hedefleri, geri al çubuğu |
| Uygulama menüsü | Sekmeler (Tümü / Sık kullanılan / kendi gruplarınız), gizli uygulamalar, A–Z hızlı kaydırma, animasyon seçenekleri, uzun basma menüsü |
| Arama | Sıralanabilir/açılıp kapanabilir kısayollar (sesli arama, Play Store, web, hava durumu), renk, şeffaflık, köşe, gölge |
| Klasörler | Simgeyi simgenin üstüne bırakarak oluşturma, canlı 2×2 önizleme, klasör içi ızgara (AUTO/3×3/4×4/5×5), yatay/dikey kaydırma, yeniden adlandırma |
| Görünüm | Dinamik Material You renkleri, açık/koyu, simge şekli, ADW/Nova uyumlu simge paketleri, animasyonları kapatma |
| Widget'lar | Android widget seçme/ekleme/yapılandırma, taşıma ve yeniden boyutlandırma paneli (uzun bas) |
| Yedekleme | Ayarlar + düzen + gruplar JSON olarak dışa/içe aktarma (widget'lar geri yüklenmez) |
| Gelişmiş | Yukarı/aşağı kaydırma ve boş alanda çift dokunma eylemleri; uygulama kilidi cihazın ekran kilidiyle (PIN/desen/parmak izi); ekranı kilitleme/bildirimler için isteğe bağlı Erişilebilirlik hizmeti |

## Bilinen sınırlar
- Kod bir derleyicide denenmeden yazıldı. İlk GitHub derlemesinde hata çıkarsa Actions günlüğünü paylaşın, düzeltelim.
- Widget taşıma/boyutlandırma sürükleme yerine ok düğmeli panelle yapılır.
- Uygulama menüsünden ana ekrana sürükleme yok; uzun basıp "Ana ekrana ekle" kullanılır.
- Uygulama kilidi yalnızca bu launcher içinde geçerlidir.
