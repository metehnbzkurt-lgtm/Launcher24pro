package com.example.materiallauncher

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import kotlin.math.ceil
import kotlin.math.sqrt

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FolderDialog(
    folderId: String,
    onDismiss: () -> Unit,
    onLaunch: (String) -> Unit
) {
    val folder = HomeStore.items.firstOrNull { it.id == folderId }
    if (folder == null || folder.type != "folder") {
        LaunchedEffect(Unit) { onDismiss() }
        return
    }
    val apps = folder.members.mapNotNull { AppRepo.index[it] }
    val radius = Settings.int("folderRadius", 46).coerceIn(0, 60).dp.coerceAtMost(40.dp)
    val n = when (Settings.str("folderGrid", "AUTO")) {
        "3×3" -> 3
        "4×4" -> 4
        "5×5" -> 5
        else -> ceil(sqrt(apps.size.toDouble())).toInt().coerceIn(2, 4)
    }
    val home = Settings.grid("homeGrid", "5×5")
    var name by remember(folder.id) { mutableStateOf(folder.name) }
    var memberMenu by remember { mutableStateOf<LaunchApp?>(null) }
    val rowHeight = 88.dp

    @Composable
    fun Tile(app: LaunchApp) {
        Column(
            Modifier.fillMaxWidth()
                .combinedClickable(onClick = { onLaunch(app.packageName); onDismiss() }, onLongClick = { memberMenu = app })
                .padding(vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AppIcon(app, iconDp(48))
            Text(
                app.label, style = MaterialTheme.typography.labelSmall, maxLines = 1,
                overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 2.dp, vertical = 2.dp)
            )
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(radius), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
            Column(Modifier.padding(16.dp)) {
                TextField(
                    value = name,
                    onValueChange = { name = it; HomeStore.renameFolder(folder.id, it) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Klasör adı") },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    )
                )
                Spacer(Modifier.height(8.dp))
                if (Settings.str("folderScroll", "Yatay") == "Yatay") {
                    val chunks: List<List<LaunchApp>> = if (apps.isEmpty()) listOf(emptyList()) else apps.chunked(n * n)
                    val pagerState = rememberPagerState(pageCount = { chunks.size })
                    val rowsShown = ceil(apps.size.coerceAtMost(n * n) / n.toDouble()).toInt().coerceAtLeast(1)
                    HorizontalPager(state = pagerState, modifier = Modifier.fillMaxWidth().height(rowHeight * rowsShown)) { p ->
                        Column {
                            chunks[p].chunked(n).forEach { rowApps ->
                                Row {
                                    rowApps.forEach { a -> Box(Modifier.weight(1f)) { Tile(a) } }
                                    repeat(n - rowApps.size) { Spacer(Modifier.weight(1f)) }
                                }
                            }
                        }
                    }
                    if (chunks.size > 1) {
                        Text(
                            "${pagerState.currentPage + 1} / ${chunks.size}",
                            Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(n),
                        modifier = Modifier.fillMaxWidth().heightIn(max = rowHeight * n),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        items(apps, key = { it.packageName }) { a -> Tile(a) }
                    }
                }
            }
        }
    }

    val mm = memberMenu
    if (mm != null) {
        AlertDialog(
            onDismissRequest = { memberMenu = null },
            title = { Text(mm.label) },
            text = {
                Column {
                    MenuRow("Ana ekrana çıkar") {
                        HomeStore.removeFromFolder(folder.id, mm.packageName, true, home.first, home.second)
                        memberMenu = null
                    }
                    MenuRow("Klasörden kaldır") {
                        HomeStore.removeFromFolder(folder.id, mm.packageName, false, home.first, home.second)
                        memberMenu = null
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { memberMenu = null }) { Text("Kapat") } }
        )
    }
}
