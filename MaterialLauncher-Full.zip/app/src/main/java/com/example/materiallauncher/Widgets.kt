package com.example.materiallauncher

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.view.View
import android.widget.TextView
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

object WidgetHost {
    private const val HOST_ID = 1024
    private var hostInternal: AppWidgetHost? = null
    private var managerInternal: AppWidgetManager? = null
    val host: AppWidgetHost get() = hostInternal!!
    val manager: AppWidgetManager get() = managerInternal!!

    fun init(context: Context) {
        if (hostInternal == null) {
            val app = context.applicationContext
            hostInternal = AppWidgetHost(app, HOST_ID)
            managerInternal = AppWidgetManager.getInstance(app)
        }
    }

    fun deleteId(id: Int) {
        if (id < 0) return
        try { host.deleteAppWidgetId(id) } catch (e: Exception) { }
    }
}

@Composable
fun WidgetView(
    widgetId: Int,
    widthPx: Int,
    heightPx: Int,
    onLongPress: () -> Unit,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current.density
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            val info = WidgetHost.manager.getAppWidgetInfo(widgetId)
            val v: View = if (info == null) {
                TextView(ctx).apply {
                    text = "Widget yüklenemedi"
                    setTextColor(android.graphics.Color.WHITE)
                }
            } else {
                WidgetHost.host.createView(ctx, widgetId, info)
            }
            v
        },
        update = { v ->
            if (v is AppWidgetHostView) {
                v.setOnLongClickListener { onLongPress(); true }
                val w = (widthPx / density).toInt()
                val h = (heightPx / density).toInt()
                v.updateAppWidgetSize(null, w, h, w, h)
            }
        }
    )
}

@Composable
fun WidgetPickerDialog(onPick: (AppWidgetProviderInfo) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val pm = context.packageManager
    val providers = remember {
        WidgetHost.manager.installedProviders.sortedBy { it.loadLabel(pm).lowercase() }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Widget ekle") },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(providers) { p ->
                    val appLabel = try {
                        pm.getApplicationLabel(pm.getApplicationInfo(p.provider.packageName, 0)).toString()
                    } catch (e: Exception) { p.provider.packageName }
                    Column(Modifier.fillMaxWidth().clickable { onPick(p) }.padding(vertical = 10.dp)) {
                        Text(p.loadLabel(pm))
                        Text(
                            "$appLabel · ${p.minWidth}×${p.minHeight} dp",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }
    )
}
