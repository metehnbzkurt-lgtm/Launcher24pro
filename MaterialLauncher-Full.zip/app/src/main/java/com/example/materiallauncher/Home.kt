package com.example.materiallauncher

import android.app.WallpaperManager
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

data class DragInfo(val item: HomeItem, val grab: Offset, val pointer: Offset, val moved: Float)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    snackbar: SnackbarHostState,
    homeSignal: Int,
    onLaunch: (String) -> Unit,
    onGesture: (String) -> Unit,
    onOpenSearch: () -> Unit,
    onShortcut: (String) -> Unit,
    onAddWidget: () -> Unit,
    onSettings: () -> Unit,
    onWallpaper: () -> Unit,
    onAppInfo: (String) -> Unit
) {
    val context = LocalContext.current
    val view = LocalView.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val launchCb by rememberUpdatedState(onLaunch)
    val gestureCb by rememberUpdatedState(onGesture)

    val grid = Settings.grid("homeGrid", "5×5")
    val cols = grid.first
    val rows = grid.second
    val pageCount = HomeStore.pages
    val pagerState = rememberPagerState(pageCount = { HomeStore.pages })

    var box by remember { mutableStateOf(IntSize.Zero) }
    var drag by remember { mutableStateOf<DragInfo?>(null) }
    var menuItemId by remember { mutableStateOf<String?>(null) }
    var folderId by remember { mutableStateOf<String?>(null) }
    var widgetEditId by remember { mutableStateOf<String?>(null) }
    var emptyMenu by remember { mutableStateOf(false) }
    var lastTap by remember { mutableLongStateOf(0L) }

    val cw = if (box.width > 0) box.width / cols.toFloat() else 1f
    val ch = if (box.height > 0) box.height / rows.toFloat() else 1f

    SideEffect {
        HomeStore.cellWpx = cw
        HomeStore.cellHpx = ch
        HomeStore.currentPage = pagerState.currentPage
    }

    LaunchedEffect(cols, rows) { HomeStore.fit(cols, rows) }
    LaunchedEffect(homeSignal) { if (homeSignal > 0) pagerState.animateScrollToPage(0) }

    // Duvar kağıdı kaydırma
    val wpScroll = Settings.bool("wallpaperScroll", true)
    LaunchedEffect(wpScroll, pageCount) {
        try {
            val wm = WallpaperManager.getInstance(context)
            val steps = (pageCount - 1).coerceAtLeast(1)
            if (wpScroll) {
                wm.setWallpaperOffsetSteps(1f / steps, 1f)
                snapshotFlow { pagerState.currentPage + pagerState.currentPageOffsetFraction }
                    .collect { p -> wm.setWallpaperOffsets(view.windowToken, (p / steps).coerceIn(0f, 1f), 0.5f) }
            } else {
                wm.setWallpaperOffsets(view.windowToken, 0.5f, 0.5f)
            }
        } catch (e: Exception) { }
    }

    // Sürüklerken ekran kenarında bekleyince sayfa değiştir (son sayfada yeni sayfa açar)
    val edgePx = with(density) { 36.dp.toPx() }
    val edge = drag?.let { d ->
        if (d.pointer.x < edgePx) -1 else if (d.pointer.x > box.width - edgePx) 1 else 0
    } ?: 0
    LaunchedEffect(edge) {
        if (edge != 0) {
            delay(650)
            while (drag != null) {
                val target = pagerState.currentPage + edge
                if (target < 0) break
                if (target >= HomeStore.pages) {
                    if (!HomeStore.addPage()) break
                    delay(120)
                }
                pagerState.animateScrollToPage(target)
                delay(700)
            }
        }
    }

    fun removeItem(item: HomeItem) {
        val removed = HomeStore.remove(item.id) ?: return
        if (removed.type == "widget") WidgetHost.deleteId(removed.widgetId)
        if (Settings.bool("undoBar", true) && removed.type != "widget") {
            scope.launch {
                val r = snackbar.showSnackbar("Kaldırıldı", "Geri al", duration = SnackbarDuration.Short)
                if (r == SnackbarResult.ActionPerformed) HomeStore.restore(removed, cols, rows)
            }
        }
    }

    fun finishDrop(d: DragInfo) {
        val cwl = box.width / cols.toFloat()
        val chl = box.height / rows.toFloat()
        val item = d.item
        val barPx = with(density) { 72.dp.toPx() }
        if (Settings.bool("dropTargets", true) && d.pointer.y < barPx) {
            if (d.pointer.x < box.width / 2f) removeItem(item)
            else if (item.type == "app") onAppInfo(item.pkg)
            return
        }
        val col = ((d.pointer.x - d.grab.x) / cwl).roundToInt().coerceIn(0, (cols - item.spanX).coerceAtLeast(0))
        val row = ((d.pointer.y - d.grab.y) / chl).roundToInt().coerceIn(0, (rows - item.spanY).coerceAtLeast(0))
        val page = pagerState.currentPage
        val occupant = HomeStore.itemAt(page, col, row, item.id)
        if (occupant == null) {
            if (HomeStore.isFree(page, col, row, item.spanX, item.spanY, cols, rows, item.id)) {
                HomeStore.update(item.copy(page = page, col = col, row = row))
            }
        } else if (item.type == "app" && occupant.type == "folder") {
            HomeStore.addToFolder(occupant.id, item.pkg, item.id)
        } else if (item.type == "app" && occupant.type == "app" && occupant.pkg != item.pkg) {
            HomeStore.mergeIntoFolder(occupant, item)
        }
        HomeStore.trimTrailing(pagerState.currentPage)
    }

    fun changeWidget(w: HomeItem, dx: Int, dy: Int, dw: Int, dh: Int) {
        val nc = w.col + dx
        val nr = w.row + dy
        val nsx = w.spanX + dw
        val nsy = w.spanY + dh
        if (nsx >= 1 && nsy >= 1 && HomeStore.isFree(w.page, nc, nr, nsx, nsy, cols, rows, w.id)) {
            HomeStore.update(w.copy(col = nc, row = nr, spanX = nsx, spanY = nsy))
        }
    }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.25f), Color.Transparent, Color.Black.copy(alpha = 0.35f)))
        )
    ) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
            val searchPos = Settings.str("homeSearch", "Alt")
            if (searchPos == "Üst") SearchPill(onClick = onOpenSearch, onShortcut = onShortcut)

            Box(
                Modifier.weight(1f).fillMaxWidth()
                    .onSizeChanged { box = it }
                    .pointerInput(cols, rows) {
                        detectTapGestures(onTap = { pos ->
                            val cwl = size.width / cols.toFloat()
                            val chl = size.height / rows.toFloat()
                            val c = (pos.x / cwl).toInt().coerceIn(0, cols - 1)
                            val r = (pos.y / chl).toInt().coerceIn(0, rows - 1)
                            val hit = HomeStore.itemAt(pagerState.currentPage, c, r, null)
                            if (hit == null) {
                                if (widgetEditId != null) {
                                    widgetEditId = null
                                } else {
                                    val now = System.currentTimeMillis()
                                    if (now - lastTap < 350) {
                                        lastTap = 0L
                                        val a = Settings.str("gestureDoubleTap", "Yok")
                                        if (a != "Yok") gestureCb(a)
                                    } else {
                                        lastTap = now
                                    }
                                }
                            } else if (hit.type == "app") {
                                launchCb(hit.pkg)
                            } else if (hit.type == "folder") {
                                folderId = hit.id
                            }
                        })
                    }
                    .pointerInput(cols, rows) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { pos ->
                                val cwl = size.width / cols.toFloat()
                                val chl = size.height / rows.toFloat()
                                val c = (pos.x / cwl).toInt().coerceIn(0, cols - 1)
                                val r = (pos.y / chl).toInt().coerceIn(0, rows - 1)
                                val hit = HomeStore.itemAt(pagerState.currentPage, c, r, null)
                                if (hit == null) {
                                    emptyMenu = true
                                } else if (hit.type != "widget") {
                                    drag = DragInfo(hit, Offset(pos.x - hit.col * cwl, pos.y - hit.row * chl), pos, 0f)
                                }
                            },
                            onDrag = { change, amount ->
                                change.consume()
                                val d = drag
                                if (d != null) {
                                    drag = d.copy(pointer = d.pointer + amount, moved = d.moved + abs(amount.x) + abs(amount.y))
                                }
                            },
                            onDragEnd = {
                                val d = drag
                                drag = null
                                if (d != null) {
                                    if (d.moved < 12.dp.toPx()) menuItemId = d.item.id else finishDrop(d)
                                }
                            },
                            onDragCancel = { drag = null }
                        )
                    }
                    .pointerInput(Unit) {
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = {
                                if (drag == null) {
                                    val th = 120.dp.toPx()
                                    if (total < -th) gestureCb(Settings.str("gestureSwipeUp", "Uygulama menüsü"))
                                    else if (total > th) gestureCb(Settings.str("gestureSwipeDown", "Yok"))
                                }
                            },
                            onDragCancel = { total = 0f },
                            onVerticalDrag = { _, dy -> total += dy }
                        )
                    }
            ) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize(),
                    userScrollEnabled = drag == null && widgetEditId == null
                ) { page ->
                    Box(Modifier.fillMaxSize()) {
                        for (item in HomeStore.items.filter { it.page == page }) {
                            key(item.id) {
                                val hidden = drag?.item?.id == item.id
                                Box(
                                    Modifier
                                        .offset { IntOffset((item.col * cw).roundToInt(), (item.row * ch).roundToInt()) }
                                        .size(with(density) { (cw * item.spanX).toDp() }, with(density) { (ch * item.spanY).toDp() })
                                        .graphicsLayer { alpha = if (hidden) 0f else 1f }
                                ) {
                                    if (item.type == "widget") {
                                        WidgetView(
                                            widgetId = item.widgetId,
                                            widthPx = (cw * item.spanX).roundToInt(),
                                            heightPx = (ch * item.spanY).roundToInt(),
                                            onLongPress = { widgetEditId = item.id },
                                            modifier = Modifier.fillMaxSize().padding(4.dp).then(
                                                if (widgetEditId == item.id)
                                                    Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp))
                                                else Modifier
                                            )
                                        )
                                    } else {
                                        CellContent(item)
                                    }
                                }
                            }
                        }
                    }
                }

                // Sürüklenen öğenin hayaleti
                val d = drag
                if (d != null) {
                    Box(
                        Modifier
                            .offset { IntOffset((d.pointer.x - d.grab.x).roundToInt(), (d.pointer.y - d.grab.y).roundToInt()) }
                            .size(with(density) { (cw * d.item.spanX).toDp() }, with(density) { (ch * d.item.spanY).toDp() })
                            .graphicsLayer { scaleX = 1.1f; scaleY = 1.1f; alpha = 0.9f }
                    ) { CellContent(d.item) }

                    if (Settings.bool("dropTargets", true)) {
                        Row(
                            Modifier.fillMaxWidth().height(72.dp).background(Color.Black.copy(alpha = 0.45f)),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Kaldır", Modifier.weight(1f), color = Color.White, textAlign = TextAlign.Center)
                            Text("Uygulama bilgisi", Modifier.weight(1f), color = Color.White, textAlign = TextAlign.Center)
                        }
                    }
                }

                // Widget düzenleme paneli: taşı / yeniden boyutlandır / kaldır
                val we = widgetEditId?.let { id -> HomeStore.items.firstOrNull { it.id == id } }
                if (we != null) {
                    Surface(
                        Modifier.align(Alignment.BottomCenter).padding(8.dp),
                        shape = RoundedCornerShape(20.dp),
                        tonalElevation = 6.dp,
                        shadowElevation = 8.dp
                    ) {
                        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Widget düzenle", style = MaterialTheme.typography.labelLarge)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("Taşı")
                                FilledTonalButton(onClick = { changeWidget(we, -1, 0, 0, 0) }, contentPadding = PaddingValues(horizontal = 14.dp)) { Text("←") }
                                FilledTonalButton(onClick = { changeWidget(we, 0, -1, 0, 0) }, contentPadding = PaddingValues(horizontal = 14.dp)) { Text("↑") }
                                FilledTonalButton(onClick = { changeWidget(we, 0, 1, 0, 0) }, contentPadding = PaddingValues(horizontal = 14.dp)) { Text("↓") }
                                FilledTonalButton(onClick = { changeWidget(we, 1, 0, 0, 0) }, contentPadding = PaddingValues(horizontal = 14.dp)) { Text("→") }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("Genişlik")
                                FilledTonalButton(onClick = { changeWidget(we, 0, 0, -1, 0) }, contentPadding = PaddingValues(horizontal = 14.dp)) { Text("−") }
                                FilledTonalButton(onClick = { changeWidget(we, 0, 0, 1, 0) }, contentPadding = PaddingValues(horizontal = 14.dp)) { Text("+") }
                                Text("Yükseklik")
                                FilledTonalButton(onClick = { changeWidget(we, 0, 0, 0, -1) }, contentPadding = PaddingValues(horizontal = 14.dp)) { Text("−") }
                                FilledTonalButton(onClick = { changeWidget(we, 0, 0, 0, 1) }, contentPadding = PaddingValues(horizontal = 14.dp)) { Text("+") }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { removeItem(we); widgetEditId = null }) { Text("Kaldır") }
                                Button(onClick = { widgetEditId = null }) { Text("Bitti") }
                            }
                        }
                    }
                }
            }

            // Sayfa göstergesi + uygulama menüsü düğmesi
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                PageIndicator(pageCount, pagerState.currentPage + pagerState.currentPageOffsetFraction, Settings.str("pageIndicator", "Noktalar"))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                IconButton(onClick = { gestureCb("Uygulama menüsü") }) {
                    Icon(Icons.Default.Apps, "Uygulama menüsü", tint = Color.White)
                }
            }
            if (searchPos == "Alt") SearchPill(onClick = onOpenSearch, onShortcut = onShortcut)
        }

        // Öğe menüsü
        val menuItem = menuItemId?.let { id -> HomeStore.items.firstOrNull { it.id == id } }
        if (menuItem != null) {
            AlertDialog(
                onDismissRequest = { menuItemId = null },
                title = { Text(if (menuItem.type == "folder") menuItem.name else (AppRepo.index[menuItem.pkg]?.label ?: "")) },
                text = {
                    Column {
                        if (menuItem.type == "folder") MenuRow("Klasörü aç") { folderId = menuItem.id; menuItemId = null }
                        if (menuItem.type == "app") MenuRow("Uygulama bilgisi") { onAppInfo(menuItem.pkg); menuItemId = null }
                        MenuRow("Kaldır") { removeItem(menuItem); menuItemId = null }
                    }
                },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { menuItemId = null }) { Text("Kapat") } }
            )
        }

        // Boş alana uzun basma menüsü
        if (emptyMenu) {
            AlertDialog(
                onDismissRequest = { emptyMenu = false },
                title = { Text("Ana ekran") },
                text = {
                    Column {
                        MenuRow("Widget ekle") { emptyMenu = false; onAddWidget() }
                        MenuRow("Sayfa ekle") { HomeStore.addPage(); emptyMenu = false }
                        MenuRow("Boş sayfaları kaldır") { HomeStore.compactPages(); emptyMenu = false }
                        MenuRow("Duvar kâğıdı") { emptyMenu = false; onWallpaper() }
                        MenuRow("Launcher ayarları") { emptyMenu = false; onSettings() }
                    }
                },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { emptyMenu = false }) { Text("Kapat") } }
            )
        }

        val fid = folderId
        if (fid != null) {
            FolderDialog(folderId = fid, onDismiss = { folderId = null }, onLaunch = { launchCb(it) })
        }
    }
}

@Composable
private fun CellContent(item: HomeItem) {
    val showLabels = Settings.bool("homeLabels", true)
    Column(
        Modifier.fillMaxSize().padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (item.type == "app") {
            val app = AppRepo.index[item.pkg]
            if (app != null) {
                AppIcon(app, iconDp(52))
                if (showLabels) HomeLabel(app.label)
            }
        } else if (item.type == "folder") {
            FolderIcon(item, iconDp(52))
            if (showLabels && Settings.bool("folderName", true)) HomeLabel(item.name)
        }
    }
}

@Composable
private fun PageIndicator(count: Int, position: Float, style: String) {
    if (style == "Hiçbiri" || count <= 1) return
    if (style == "Çizgi") {
        val seg = 96.dp / count
        Box(
            Modifier.padding(vertical = 6.dp).width(96.dp).height(4.dp)
                .background(Color.White.copy(alpha = 0.3f), RoundedCornerShape(2.dp))
        ) {
            Box(
                Modifier.offset(x = seg * position.coerceIn(0f, (count - 1).toFloat()))
                    .width(seg).height(4.dp).background(Color.White, RoundedCornerShape(2.dp))
            )
        }
    } else {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            repeat(count) { i ->
                Box(
                    Modifier.size(7.dp).background(
                        Color.White.copy(alpha = if (i == position.roundToInt()) 1f else 0.4f), CircleShape
                    )
                )
            }
        }
    }
}
