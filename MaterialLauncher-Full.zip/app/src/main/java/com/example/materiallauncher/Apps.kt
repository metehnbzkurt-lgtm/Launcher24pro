package com.example.materiallauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.graphics.drawable.Drawable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.text.Collator
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

object AppRepo {
    var apps by mutableStateOf<List<LaunchApp>>(emptyList())
        private set
    var index by mutableStateOf<Map<String, LaunchApp>>(emptyMap())
        private set
    var loaded by mutableStateOf(false)
        private set
    var iconVersion by mutableIntStateOf(0)
        private set

    private val cache = ConcurrentHashMap<String, ImageBitmap>()
    private var packRes: Resources? = null
    private var packPkg: String = ""
    private var packMap: Map<String, String> = emptyMap()

    fun peek(pkg: String): ImageBitmap? = cache[pkg]

    suspend fun load(context: Context) {
        val list = withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val collator = Collator.getInstance(Locale("tr", "TR"))
            pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
                .map { LaunchApp(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name) }
                .filter { it.packageName != context.packageName }
                .distinctBy { it.packageName }
                .sortedWith(Comparator { a, b -> collator.compare(a.label, b.label) })
        }
        apps = list
        index = list.associateBy { it.packageName }
        loaded = true
        cache.clear()
        iconVersion++
    }

    suspend fun iconFor(context: Context, app: LaunchApp): ImageBitmap = withContext(Dispatchers.Default) {
        val hit = cache[app.packageName]
        if (hit != null) {
            hit
        } else {
            val bmp = loadIcon(context, app)
            cache[app.packageName] = bmp
            bmp
        }
    }

    private fun loadIcon(context: Context, app: LaunchApp): ImageBitmap {
        val pm = context.packageManager
        val cn = ComponentName(app.packageName, app.activity)
        var d: Drawable? = null
        val res = packRes
        if (res != null) {
            val name = packMap[cn.flattenToString()] ?: packMap[app.packageName + "/"]
            if (name != null) {
                val id = res.getIdentifier(name, "drawable", packPkg)
                if (id != 0) {
                    d = try { res.getDrawable(id, null) } catch (e: Exception) { null }
                }
            }
        }
        if (d == null) {
            d = try { pm.getActivityIcon(cn) } catch (e: Exception) { pm.defaultActivityIcon }
        }
        return d!!.toBitmap(128, 128).asImageBitmap()
    }

    /** Ayarlardaki "iconPack" değerine göre simge paketini yükler (boş = sistem simgeleri). */
    suspend fun applyIconPack(context: Context) {
        val pkg = Settings.str("iconPack", "")
        withContext(Dispatchers.IO) {
            packRes = null
            packMap = emptyMap()
            packPkg = pkg
            if (pkg.isNotEmpty()) {
                try { parsePack(context, pkg) } catch (e: Exception) { }
            }
        }
        cache.clear()
        iconVersion++
    }

    private fun parsePack(context: Context, pkg: String) {
        val res = context.packageManager.getResourcesForApplication(pkg)
        val map = HashMap<String, String>()
        val xmlId = res.getIdentifier("appfilter", "xml", pkg)
        val parser: XmlPullParser? = if (xmlId != 0) {
            res.getXml(xmlId)
        } else {
            try {
                val p = XmlPullParserFactory.newInstance().newPullParser()
                p.setInput(res.assets.open("appfilter.xml"), null)
                p
            } catch (e: Exception) { null }
        }
        if (parser == null) return
        var ev = parser.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && parser.name == "item") {
                val comp = parser.getAttributeValue(null, "component")
                val dr = parser.getAttributeValue(null, "drawable")
                if (comp != null && dr != null && comp.startsWith("ComponentInfo{")) {
                    val flat = comp.removePrefix("ComponentInfo{").removeSuffix("}")
                    map[flat] = dr
                    val p = flat.substringBefore("/") + "/"
                    if (!map.containsKey(p)) map[p] = dr
                }
            }
            ev = parser.next()
        }
        packRes = res
        packMap = map
    }

    /** (etiket, paket adı) listesi. ADW / Nova uyumlu simge paketleri. */
    fun iconPacks(context: Context): List<Pair<String, String>> {
        val pm = context.packageManager
        val actions = listOf("org.adw.launcher.THEMES", "com.novalauncher.THEME", "com.gau.go.launcherex.theme")
        val out = LinkedHashMap<String, String>()
        for (a in actions) {
            for (ri in pm.queryIntentActivities(Intent(a), 0)) {
                out[ri.activityInfo.packageName] = ri.loadLabel(pm).toString()
            }
        }
        return out.entries.map { Pair(it.value, it.key) }.sortedBy { it.first }
    }
}
