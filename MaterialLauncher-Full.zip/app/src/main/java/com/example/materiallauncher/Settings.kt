package com.example.materiallauncher

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/** Tüm ayarlar tek SharedPreferences dosyasında tutulur; tick değişince okuyan Compose bileşenleri yenilenir. */
object Settings {
    private var prefsInternal: SharedPreferences? = null
    val prefs: SharedPreferences get() = prefsInternal!!

    var tick by mutableIntStateOf(0)
        private set

    fun init(context: Context) {
        if (prefsInternal == null) {
            prefsInternal = context.applicationContext.getSharedPreferences("launcher_settings", Context.MODE_PRIVATE)
        }
    }

    fun notifyChanged() { tick++ }

    fun bool(key: String, def: Boolean): Boolean {
        if (tick < 0) return def
        return prefs.getBoolean(key, def)
    }

    fun str(key: String, def: String): String {
        if (tick < 0) return def
        return prefs.getString(key, def) ?: def
    }

    fun int(key: String, def: Int): Int {
        if (tick < 0) return def
        return prefs.getInt(key, def)
    }

    fun putBool(key: String, v: Boolean) { prefs.edit().putBoolean(key, v).apply(); tick++ }
    fun putStr(key: String, v: String) { prefs.edit().putString(key, v).apply(); tick++ }
    fun putInt(key: String, v: Int) { prefs.edit().putInt(key, v).apply(); tick++ }

    /** "5×5" gibi bir değeri (sütun, satır) çiftine çevirir. */
    fun grid(key: String, def: String): Pair<Int, Int> {
        val parts = str(key, def).split("×")
        val c = parts.getOrNull(0)?.trim()?.toIntOrNull() ?: 4
        val r = parts.getOrNull(1)?.trim()?.toIntOrNull() ?: 5
        return Pair(c.coerceIn(3, 8), r.coerceIn(3, 8))
    }
}
